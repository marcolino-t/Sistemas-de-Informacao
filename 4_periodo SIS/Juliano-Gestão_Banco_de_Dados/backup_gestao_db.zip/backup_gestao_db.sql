-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           11.3.2-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Copiando estrutura para tabela comercial.comclien
CREATE TABLE IF NOT EXISTS `comclien` (
  `n_numeclien` int(11) NOT NULL AUTO_INCREMENT,
  `c_codiclien` varchar(10) DEFAULT NULL,
  `c_nomeclien` varchar(100) DEFAULT NULL,
  `c_razaoclien` varchar(100) DEFAULT NULL,
  `d_dataclien` date DEFAULT NULL,
  `c_cnpjclien` varchar(20) DEFAULT NULL,
  `c_foneclien` varchar(20) DEFAULT NULL,
  `c_cidaclien` varchar(50) DEFAULT NULL,
  `c_estaclien` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`n_numeclien`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comclien: ~10 rows (aproximadamente)
REPLACE INTO `comclien` (`n_numeclien`, `c_codiclien`, `c_nomeclien`, `c_razaoclien`, `d_dataclien`, `c_cnpjclien`, `c_foneclien`, `c_cidaclien`, `c_estaclien`) VALUES
	(1, '0001', 'AARONSON FURNITURE', 'AARONSON FURNITURE LTD', '2015-02-17', '17.807.928/0001-85', '(21) 8167-6584', 'QUEIMADOS', 'RJ'),
	(2, '0002', 'LITTLER ', 'LITTLER  LTDA', '2015-02-17', '55.643.605/0001-92', '(27) 7990-9502', 'SERRA', 'ES'),
	(3, '0003', 'KELSEY  NEIGHBOURHOOD', 'KELSEY  NEIGHBOURHOOD', '2015-02-17', '05.202.361/0001-34', '(11) 4206-9703', 'BRAGANÇA PAULISTA', 'SP'),
	(4, '0004', 'GREAT AMERICAN MUSIC', 'GREAT AMERICAN MUSIC', '2015-02-17', '11.880.735/0001-73', '(75) 7815-7801', 'SANTO ANTÔNIO DE JESUS', 'BA'),
	(5, '0005', 'LIFE PLAN COUNSELLING', 'LIFE PLAN COUNSELLING', '2015-02-17', '75.185.467/0001-52', '(17) 4038-9355', 'BEBEDOURO', 'SP'),
	(6, '0006', 'PRACTI-PLAN', 'PRACTI-PLAN LTDA', '2015-02-17', '32.518.106/0001-78', '(28) 2267-6159', 'CACHOEIRO DE ITAPEMIRI', 'ES'),
	(7, '0007', 'SPORTSWEST', 'SPORTSWEST LTDA', '2015-02-17', '83.175.645/0001-92', '(61) 4094-7184', 'TAGUATINGA', 'DF'),
	(8, '0008', 'HUGHES MARKETS', 'HUGHES MARKETS LTDA', '2015-02-17', '04.728.160/0001-02', '(21) 7984-9809', 'RIO DE JANEIRO', 'RJ'),
	(9, '0009', 'AUTO WORKS', 'AUTO WORKS LTDA', '2015-02-17', '08.271.985/0001-00', '(21) 8548-5555', 'RIO DE JANEIRO', 'RJ'),
	(10, '00010', 'DAHLKEMPER ', 'DAHLKEMPER  LTDA', '2015-02-17', '49.815.047/0001-00', '(11) 4519-7670', 'SÃO PAULO', 'SP');

-- Copiando estrutura para tabela comercial.comforne
CREATE TABLE IF NOT EXISTS `comforne` (
  `n_numeforme` int(11) NOT NULL AUTO_INCREMENT,
  `c_codiforne` varchar(10) DEFAULT NULL,
  `c_nomeforne` varchar(100) DEFAULT NULL,
  `c_razaforne` varchar(100) DEFAULT NULL,
  `c_foneforne` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`n_numeforme`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comforne: ~2 rows (aproximadamente)
REPLACE INTO `comforne` (`n_numeforme`, `c_codiforne`, `c_nomeforne`, `c_razaforne`, `c_foneforne`) VALUES
	(1, '0001', 'DUN RITE LAWN MAINTENANCE', 'DUN RITE LAWN MAINTENANCE LTDA', '(85) 7886-8837'),
	(2, '0002', 'SEWFRO FABRICS', 'SEWFRO FABRICS LTDA', '(91) 5171-8483');

-- Copiando estrutura para tabela comercial.comivenda
CREATE TABLE IF NOT EXISTS `comivenda` (
  `n_numeivenda` int(11) NOT NULL AUTO_INCREMENT,
  `n_numevenda` int(11) NOT NULL,
  `n_numeprodu` int(11) NOT NULL,
  `n_valorivenda` float(10,2) DEFAULT NULL,
  `n_qtdeivenda` int(11) DEFAULT NULL,
  `n_descivenda` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`n_numeivenda`),
  KEY `fk_comivenda_comprodu` (`n_numeprodu`),
  KEY `fk_comivenda_comvenda` (`n_numevenda`),
  CONSTRAINT `fk_comivenda_comprodu` FOREIGN KEY (`n_numeprodu`) REFERENCES `comprodu` (`n_numeprodu`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_comivenda_comvenda` FOREIGN KEY (`n_numevenda`) REFERENCES `comvenda` (`n_numevenda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comivenda: ~6 rows (aproximadamente)
REPLACE INTO `comivenda` (`n_numeivenda`, `n_numevenda`, `n_numeprodu`, `n_valorivenda`, `n_qtdeivenda`, `n_descivenda`) VALUES
	(1, 1, 1, 1251.29, 1, 0.00),
	(2, 1, 2, 1242.21, 2, 0.00),
	(3, 1, 3, 1241.21, 3, 0.00),
	(4, 1, 4, 1513.77, 4, 0.00),
	(5, 1, 5, 2325.32, 5, 0.00),
	(6, 2, 1, 1251.29, 6, 0.00);

-- Copiando estrutura para tabela comercial.comprodu
CREATE TABLE IF NOT EXISTS `comprodu` (
  `n_numeprodu` int(11) NOT NULL AUTO_INCREMENT,
  `c_codiprodu` varchar(20) DEFAULT NULL,
  `c_descprodu` varchar(100) DEFAULT NULL,
  `n_valoprodu` float(10,2) DEFAULT NULL,
  `c_situprodu` varchar(1) DEFAULT NULL,
  `n_numeforne` int(11) DEFAULT NULL,
  PRIMARY KEY (`n_numeprodu`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comprodu: ~5 rows (aproximadamente)
REPLACE INTO `comprodu` (`n_numeprodu`, `c_codiprodu`, `c_descprodu`, `n_valoprodu`, `c_situprodu`, `n_numeforne`) VALUES
	(1, '123131', 'NOTEBOOK', 1251.29, 'A', 1),
	(2, '123223', 'SMARTPHONE', 1242.21, 'A', 2),
	(3, '1231', 'DESKTOP', 1241.21, 'A', 1),
	(4, '142123', 'TELEVISÃO', 2564.92, 'A', 2),
	(5, '7684', 'DRONE', 2325.32, 'A', 1);

-- Copiando estrutura para tabela comercial.comvenda
CREATE TABLE IF NOT EXISTS `comvenda` (
  `n_numevenda` int(11) NOT NULL AUTO_INCREMENT,
  `c_codivenda` varchar(10) DEFAULT NULL,
  `n_numeclien` int(11) NOT NULL,
  `n_numeforne` int(11) NOT NULL,
  `n_numevende` int(11) NOT NULL,
  `n_valorvenda` float(10,2) DEFAULT NULL,
  `n_descvenda` float(10,2) DEFAULT NULL,
  `n_totavenda` float(10,2) DEFAULT NULL,
  `d_datavenda` date DEFAULT NULL,
  `n_vcomvenda` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`n_numevenda`),
  KEY `fk_comvenda_comclien` (`n_numeclien`),
  KEY `fk_comprodu_comvende` (`n_numevende`),
  KEY `fk_comprodu_comforne` (`n_numeforne`),
  CONSTRAINT `fk_comprodu_comforne` FOREIGN KEY (`n_numeforne`) REFERENCES `comforne` (`n_numeforme`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_comprodu_comvende` FOREIGN KEY (`n_numevende`) REFERENCES `comvende` (`n_numevende`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_comvenda_comclien` FOREIGN KEY (`n_numeclien`) REFERENCES `comclien` (`n_numeclien`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comvenda: ~20 rows (aproximadamente)
REPLACE INTO `comvenda` (`n_numevenda`, `c_codivenda`, `n_numeclien`, `n_numeforne`, `n_numevende`, `n_valorvenda`, `n_descvenda`, `n_totavenda`, `d_datavenda`, `n_vcomvenda`) VALUES
	(1, '1', 1, 1, 1, 25141.02, 0.00, 25141.02, '2015-01-01', NULL),
	(2, '2', 2, 2, 2, 12476.58, 0.00, 12476.58, '2015-01-02', NULL),
	(3, '3', 3, 1, 1, 16257.32, 0.00, 16257.32, '2015-01-03', NULL),
	(4, '4', 4, 2, 2, 8704.55, 0.00, 8704.55, '2015-01-04', NULL),
	(5, '5', 5, 1, 1, 13078.81, 0.00, 13078.81, '2015-01-01', NULL),
	(6, '6', 6, 2, 2, 6079.19, 0.00, 6079.19, '2015-01-02', NULL),
	(7, '7', 7, 1, 1, 7451.26, 0.00, 7451.26, '2015-01-03', NULL),
	(8, '8', 8, 2, 2, 15380.47, 0.00, 15380.47, '2015-01-04', NULL),
	(9, '9', 9, 1, 1, 13508.34, 0.00, 13508.34, '2015-01-01', NULL),
	(10, '10', 1, 2, 2, 20315.07, 0.00, 20315.07, '2015-01-02', NULL),
	(11, '11', 1, 1, 1, 8704.55, 0.00, 8704.55, '2015-01-01', NULL),
	(12, '12', 2, 2, 2, 11198.05, 0.00, 11198.05, '2015-01-02', NULL),
	(13, '13', 3, 1, 1, 4967.84, 0.00, 4967.84, '2015-01-03', NULL),
	(14, '14', 3, 2, 2, 7451.26, 0.00, 7451.26, '2015-01-04', NULL),
	(15, '15', 5, 1, 1, 10747.36, 0.00, 10747.36, '2015-01-01', NULL),
	(16, '16', 6, 2, 2, 13502.34, 0.00, 13502.34, '2015-01-02', NULL),
	(17, '17', 7, 1, 1, 22222.99, 0.00, 22222.99, '2015-01-03', NULL),
	(18, '18', 8, 2, 2, 15465.69, 0.00, 15465.69, '2015-01-04', NULL),
	(19, '19', 9, 1, 1, 4650.64, 0.00, 4650.64, '2015-01-01', NULL),
	(20, '20', 9, 2, 2, 6975.96, 0.00, 6975.96, '2015-01-02', NULL);

-- Copiando estrutura para tabela comercial.comvende
CREATE TABLE IF NOT EXISTS `comvende` (
  `n_numevende` int(11) NOT NULL AUTO_INCREMENT,
  `c_codivende` varchar(10) DEFAULT NULL,
  `c_nomevende` varchar(100) DEFAULT NULL,
  `c_razavende` varchar(100) DEFAULT NULL,
  `c_fonevende` varchar(20) DEFAULT NULL,
  `n_porcvende` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`n_numevende`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Copiando dados para a tabela comercial.comvende: ~2 rows (aproximadamente)
REPLACE INTO `comvende` (`n_numevende`, `c_codivende`, `c_nomevende`, `c_razavende`, `c_fonevende`, `n_porcvende`) VALUES
	(1, '0001', 'CARLOS FERNANDES', 'CARLOS FERNANDES LTDA', '(47) 7535-8144', 12.00),
	(2, '0002', 'JÚLIA	GOMES', 'JÚLIA GOMES LTDA', '(12) 8037-6661', 25.00);

-- Copiando estrutura para função comercial.rt_nome_cliente
DELIMITER //
CREATE FUNCTION `rt_nome_cliente`(vn_numeclien INT) RETURNS varchar(50) CHARSET latin1 COLLATE latin1_swedish_ci
BEGIN 
			DECLARE nome VARCHAR(50);
			
			SELECT c_nomeclien INTO nome
			FROM comclien
			WHERE n_numeclien = vn_numeclien;
			
			RETURN nome;
		END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
